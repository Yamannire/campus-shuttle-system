const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { Sequelize, DataTypes } = require('sequelize');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Middleware
app.use(cors());
app.use(express.json());

// JWT Secret
const JWT_SECRET = 'campus-shuttle-secret-key-2026';

// Database Setup (SQLite for development)
const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './database.sqlite',
    logging: false
});

// ===========================
// MODELS
// ===========================

// User Model
const User = sequelize.define('User', {
    name: { type: DataTypes.STRING, allowNull: false },
    email: { type: DataTypes.STRING, allowNull: false, unique: true },
    password: { type: DataTypes.STRING, allowNull: false },
    role: { 
        type: DataTypes.ENUM('student', 'driver', 'coordinator', 'admin'), 
        allowNull: false 
    }
});

// Route Model
const Route = sequelize.define('Route', {
    name: { type: DataTypes.STRING, allowNull: false },
    start_location: { type: DataTypes.STRING },
    end_location: { type: DataTypes.STRING },
    is_active: { type: DataTypes.BOOLEAN, defaultValue: true }
});

// Stop Model
const Stop = sequelize.define('Stop', {
    stop_name: { type: DataTypes.STRING, allowNull: false },
    order_index: { type: DataTypes.INTEGER, allowNull: false },
    lat: { type: DataTypes.FLOAT },
    lng: { type: DataTypes.FLOAT }
});

// Schedule Model
const Schedule = sequelize.define('Schedule', {
    departure_time: { type: DataTypes.TIME, allowNull: false },
    bus_number: { type: DataTypes.STRING },
    capacity: { type: DataTypes.INTEGER, defaultValue: 40 }
});

// Booking Model
const Booking = sequelize.define('Booking', {
    pickup_stop: { type: DataTypes.STRING },
    status: { 
        type: DataTypes.ENUM('confirmed', 'cancelled', 'completed'), 
        defaultValue: 'confirmed' 
    }
});

// Incident Model
const Incident = sequelize.define('Incident', {
    type: { 
        type: DataTypes.ENUM('delay', 'breakdown', 'accident', 'other'), 
        allowNull: false 
    },
    description: { type: DataTypes.TEXT, allowNull: false },
    status: { 
        type: DataTypes.ENUM('pending', 'resolved'), 
        defaultValue: 'pending' 
    }
});

// Notification Model
const Notification = sequelize.define('Notification', {
    message: { type: DataTypes.TEXT, allowNull: false },
    type: { 
        type: DataTypes.ENUM('alert', 'info', 'warning'), 
        defaultValue: 'info' 
    },
    target_role: { type: DataTypes.STRING }
});

// Location Model (for real-time tracking)
const Location = sequelize.define('Location', {
    lat: { type: DataTypes.FLOAT, allowNull: false },
    lng: { type: DataTypes.FLOAT, allowNull: false }
});

// ===========================
// ASSOCIATIONS
// ===========================

Route.hasMany(Stop, { onDelete: 'CASCADE' });
Stop.belongsTo(Route);

Route.hasMany(Schedule, { onDelete: 'CASCADE' });
Schedule.belongsTo(Route);

User.hasMany(Booking, { foreignKey: 'userId' });
Booking.belongsTo(User, { foreignKey: 'userId' });

Schedule.hasMany(Booking, { foreignKey: 'scheduleId' });
Booking.belongsTo(Schedule, { foreignKey: 'scheduleId' });

User.hasMany(Incident, { foreignKey: 'driverId' });
Incident.belongsTo(User, { as: 'driver', foreignKey: 'driverId' });

Route.hasMany(Location, { onDelete: 'CASCADE' });
Location.belongsTo(Route);

// ===========================
// AUTH MIDDLEWARE
// ===========================

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access denied' });
    }

    try {
        const verified = jwt.verify(token, JWT_SECRET);
        req.user = verified;
        next();
    } catch (err) {
        res.status(403).json({ error: 'Invalid token' });
    }
};

// ===========================
// AUTH ROUTES
// ===========================

// Register
app.post('/api/register', async (req, res) => {
    try {
        const { name, email, password, role } = req.body;

        const existingUser = await User.findOne({ where: { email } });
        if (existingUser) {
            return res.status(400).json({ error: 'Email already registered' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({
            name,
            email,
            password: hashedPassword,
            role
        });

        res.status(201).json({ message: 'User registered successfully', userId: user.id });
    } catch (error) {
        res.status(500).json({ error: 'Registration failed' });
    }
});

// Login
app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ where: { email } });
        if (!user) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign(
            { id: user.id, email: user.email, role: user.role },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({
            token,
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role
            }
        });
    } catch (error) {
        res.status(500).json({ error: 'Login failed' });
    }
});

// ===========================
// ROUTES API
// ===========================

// Get all routes
app.get('/api/routes', authenticateToken, async (req, res) => {
    try {
        const routes = await Route.findAll({
            include: [{ model: Stop, order: [['order_index', 'ASC']] }],
            where: { is_active: true }
        });
        res.json(routes);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch routes' });
    }
});

// ===========================
// SCHEDULES API
// ===========================

// Get schedules for a route
app.get('/api/schedules/:routeId', authenticateToken, async (req, res) => {
    try {
        const schedules = await Schedule.findAll({
            where: { RouteId: req.params.routeId },
            include: [Route]
        });
        res.json(schedules);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch schedules' });
    }
});

// ===========================
// BOOKINGS API
// ===========================

// Create booking
app.post('/api/bookings', authenticateToken, async (req, res) => {
    try {
        const { schedule_id, pickup_stop } = req.body;

        // Check capacity
        const schedule = await Schedule.findByPk(schedule_id);
        const existingBookings = await Booking.count({
            where: { scheduleId: schedule_id, status: 'confirmed' }
        });

        if (existingBookings >= schedule.capacity) {
            return res.status(400).json({ error: 'No seats available' });
        }

        const booking = await Booking.create({
            userId: req.user.id,
            scheduleId: schedule_id,
            pickup_stop,
            status: 'confirmed'
        });

        res.status(201).json({ message: 'Booking confirmed', booking });
    } catch (error) {
        res.status(500).json({ error: 'Booking failed' });
    }
});

// Get user's bookings
app.get('/api/bookings/my', authenticateToken, async (req, res) => {
    try {
        const bookings = await Booking.findAll({
            where: { userId: req.user.id },
            include: [{ 
                model: Schedule, 
                include: [Route] 
            }],
            order: [['createdAt', 'DESC']]
        });
        res.json(bookings);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch bookings' });
    }
});

// ===========================
// INCIDENTS API
// ===========================

// Report incident
app.post('/api/incidents', authenticateToken, async (req, res) => {
    try {
        const { type, description } = req.body;

        const incident = await Incident.create({
            driverId: req.user.id,
            type,
            description,
            status: 'pending'
        });

        // Broadcast to admins/coordinators
        io.emit('new-notification', {
            message: `⚠️ New incident reported: ${type}`
        });

        res.status(201).json({ message: 'Incident reported', incident });
    } catch (error) {
        res.status(500).json({ error: 'Failed to report incident' });
    }
});

// ===========================
// NOTIFICATIONS API
// ===========================

// Send notification
app.post('/api/notifications', authenticateToken, async (req, res) => {
    try {
        if (req.user.role !== 'admin' && req.user.role !== 'coordinator') {
            return res.status(403).json({ error: 'Not authorized' });
        }

        const { message, type, target_role } = req.body;

        const notification = await Notification.create({
            message,
            type,
            target_role
        });

        // Broadcast to all connected clients
        io.emit('new-notification', { message });

        res.status(201).json({ message: 'Notification sent', notification });
    } catch (error) {
        res.status(500).json({ error: 'Failed to send notification' });
    }
});

// Get notifications
app.get('/api/notifications', authenticateToken, async (req, res) => {
    try {
        const notifications = await Notification.findAll({
            order: [['createdAt', 'DESC']],
            limit: 10
        });
        res.json(notifications);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch notifications' });
    }
});

// ===========================
// ADMIN STATISTICS API
// ===========================

app.get('/api/stats', authenticateToken, async (req, res) => {
    try {
        if (req.user.role !== 'admin' && req.user.role !== 'coordinator') {
            return res.status(403).json({ error: 'Not authorized' });
        }

        const totalUsers = await User.count();
        const totalBookings = await Booking.count({ where: { status: 'confirmed' } });
        const activeRouteCount = await Route.count({ where: { is_active: true } });
        const recentIncidents = await Incident.count({ where: { status: 'pending' } });

        res.json({
            totalUsers,
            totalBookings,
            activeRouteCount,
            recentIncidents
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch stats' });
    }
});

// ===========================
// SOCKET.IO REAL-TIME
// ===========================

io.on('connection', (socket) => {
    console.log('✅ New client connected:', socket.id);

    socket.on('join-route', (routeId) => {
        socket.join(`route-${routeId}`);
        console.log(`📍 Client joined route: ${routeId}`);
    });

    socket.on('update-location', async (data) => {
        const { routeId, lat, lng } = data;
        
        // Save to database
        await Location.create({
            RouteId: routeId,
            lat,
            lng
        });

        // Broadcast to all clients in this route
        io.to(`route-${routeId}`).emit('location-update', { lat, lng });
    });

    socket.on('disconnect', () => {
        console.log('❌ Client disconnected:', socket.id);
    });
});

// ===========================
// DATABASE INITIALIZATION
// ===========================

async function initDatabase() {
    try {
        await sequelize.sync({ force: false });
        console.log('✅ Database synced');

        // Check if we need to seed data
        const userCount = await User.count();
        if (userCount === 0) {
            console.log('📦 Seeding initial data...');
            await seedData();
        }
    } catch (error) {
        console.error('❌ Database error:', error);
    }
}

async function seedData() {
    // Create demo users
    const users = [
        { name: 'Student User', email: 'student@mmu.edu.my', password: 'student123', role: 'student' },
        { name: 'Driver User', email: 'driver@mmu.edu.my', password: 'driver123', role: 'driver' },
        { name: 'Coordinator User', email: 'coord@mmu.edu.my', password: 'coord123', role: 'coordinator' },
        { name: 'Admin User', email: 'admin@mmu.edu.my', password: 'admin123', role: 'admin' }
    ];

    for (const userData of users) {
        const hashedPassword = await bcrypt.hash(userData.password, 10);
        await User.create({ ...userData, password: hashedPassword });
    }

    // Create demo routes
    const route1 = await Route.create({
        name: 'Campus Loop A',
        start_location: 'Main Gate',
        end_location: 'Library',
        is_active: true
    });

    const route2 = await Route.create({
        name: 'Hostel Express',
        start_location: 'Dormitory',
        end_location: 'Engineering Faculty',
        is_active: true
    });

    // Create stops for routes
    const route1Stops = [
        { stop_name: 'Main Gate', order_index: 0, lat: 2.9279, lng: 101.6413 },
        { stop_name: 'Faculty of Engineering', order_index: 1, lat: 2.9285, lng: 101.6420 },
        { stop_name: 'Student Center', order_index: 2, lat: 2.9290, lng: 101.6425 },
        { stop_name: 'Library', order_index: 3, lat: 2.9295, lng: 101.6430 }
    ];

    for (const stop of route1Stops) {
        await Stop.create({ ...stop, RouteId: route1.id });
    }

    const route2Stops = [
        { stop_name: 'Dormitory Block A', order_index: 0, lat: 2.9270, lng: 101.6410 },
        { stop_name: 'Sports Complex', order_index: 1, lat: 2.9275, lng: 101.6418 },
        { stop_name: 'Engineering Faculty', order_index: 2, lat: 2.9285, lng: 101.6420 }
    ];

    for (const stop of route2Stops) {
        await Stop.create({ ...stop, RouteId: route2.id });
    }

    // Create schedules
    await Schedule.create({
        RouteId: route1.id,
        departure_time: '08:00:00',
        bus_number: 'MMU-001',
        capacity: 40
    });

    await Schedule.create({
        RouteId: route1.id,
        departure_time: '09:00:00',
        bus_number: 'MMU-002',
        capacity: 40
    });

    await Schedule.create({
        RouteId: route2.id,
        departure_time: '08:30:00',
        bus_number: 'MMU-003',
        capacity: 35
    });

    console.log('✅ Database seeded successfully!');
}

// ===========================
// START SERVER
// ===========================

const PORT = process.env.PORT || 3000;

initDatabase().then(() => {
    server.listen(PORT, () => {
        console.log(`
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║     🚌 CAMPUS SHUTTLE SYSTEM - BACKEND SERVER        ║
║                                                       ║
║     Status: ✅ Running                                ║
║     Port: ${PORT}                                      ║
║     Environment: Development                          ║
║                                                       ║
║     API: http://localhost:${PORT}/api                  ║
║     Socket.IO: http://localhost:${PORT}                ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
        `);
    });
});
