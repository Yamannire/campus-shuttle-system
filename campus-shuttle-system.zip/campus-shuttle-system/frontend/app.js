// API Configuration
const API_URL = 'https://4xwcsr7j-3000.asse.devtunnels.ms/';
const SOCKET_URL = 'https://4xwcsr7j-3000.asse.devtunnels.ms/';

// Global State
let currentUser = null;
let token = null;
let socket = null;
let map = null;
let busMarker = null;
let userMarker = null;
let isRegistering = false;
let watchId = null;
let allRoutes = [];
let routeStopMarkers = [];

// ===========================
// INITIALIZATION
// ===========================

// Initialize Map
function initMap() {
    if (map) return;
    
    // Center on MMU Cyberjaya
    map = L.map('map').setView([2.9279, 101.6413], 15);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    // Add user location marker
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
            const userLat = position.coords.latitude;
            const userLng = position.coords.longitude;
            
            const userIcon = L.icon({
                iconUrl: 'data:image/svg+xml;base64,' + btoa('<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#3b82f6"><circle cx="12" cy="12" r="10" stroke="white" stroke-width="2"/></svg>'),
                iconSize: [24, 24]
            });
            
            userMarker = L.marker([userLat, userLng], { icon: userIcon })
                .addTo(map)
                .bindPopup('📍 Your Location');
        });
    }
}

// ===========================
// AUTHENTICATION
// ===========================

// Auth Toggle
document.getElementById('toggle-auth').addEventListener('click', (e) => {
    e.preventDefault();
    isRegistering = !isRegistering;
    document.getElementById('auth-title').innerText = isRegistering ? 'Create Account' : 'Welcome Back';
    document.getElementById('name-field').classList.toggle('hidden', !isRegistering);
    document.getElementById('role-field').classList.toggle('hidden', !isRegistering);
    document.getElementById('toggle-auth').innerText = isRegistering 
        ? 'Already have an account? Login' 
        : "Don't have an account? Register";
});

// Auth Form Submit
document.getElementById('auth-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
        if (isRegistering) {
            const name = document.getElementById('name').value;
            const role = document.getElementById('role').value;
            
            await axios.post(`${API_URL}/register`, { name, email, password, role });
            showToast('Registration successful! Please login.', 'success');
            document.getElementById('toggle-auth').click();
            document.getElementById('auth-form').reset();
        } else {
            const response = await axios.post(`${API_URL}/login`, { email, password });
            token = response.data.token;
            currentUser = response.data.user;
            
            localStorage.setItem('shuttle_token', token);
            localStorage.setItem('shuttle_user', JSON.stringify(currentUser));
            
            showToast(`Welcome back, ${currentUser.name}!`, 'success');
            showDashboard();
        }
    } catch (error) {
        showToast(error.response?.data?.error || 'Authentication failed', 'error');
    }
});

// Logout
document.getElementById('logout-btn').addEventListener('click', () => {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('shuttle_token');
        localStorage.removeItem('shuttle_user');
        if (socket) socket.disconnect();
        location.reload();
    }
});

// Demo Buttons Logic
document.querySelectorAll('.demo-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.getElementById('email').value = btn.dataset.email;
        document.getElementById('password').value = btn.dataset.pass;
    });
});

// ===========================
// DASHBOARD
// ===========================

async function showDashboard() {
    document.getElementById('auth-section').classList.add('hidden');
    document.getElementById('dashboard-section').classList.remove('hidden');
    document.getElementById('logout-btn').classList.remove('hidden');
    document.getElementById('user-name').innerText = currentUser.name;
    document.getElementById('user-role').innerText = currentUser.role.toUpperCase();

    initMap();
    initSocket();
    await loadRoutes();
    loadNotifications();

    // Show role-specific controls
    if (currentUser.role === 'student') {
        document.getElementById('student-controls').classList.remove('hidden');
    } else if (currentUser.role === 'driver') {
        document.getElementById('driver-controls').classList.remove('hidden');
    } else if (currentUser.role === 'admin' || currentUser.role === 'coordinator') {
        document.getElementById('admin-controls').classList.remove('hidden');
        loadAdminStats();
    }
}

// ===========================
// SOCKET.IO REAL-TIME
// ===========================

function initSocket() {
    if (socket) return;
    
    socket = io(SOCKET_URL, {
        auth: { token }
    });

    socket.on('connect', () => {
        console.log('✅ Connected to server');
    });

    socket.on('location-update', (data) => {
        console.log('📍 Location update:', data);
        updateBusMarker(data.lat, data.lng);
    });

    socket.on('new-notification', (note) => {
        console.log('🔔 New notification:', note);
        showNotification(note.message);
        showToast(note.message, 'success');
    });

    socket.on('disconnect', () => {
        console.log('❌ Disconnected from server');
    });
}

function showNotification(msg) {
    const banner = document.getElementById('notification-banner');
    document.getElementById('latest-notification').innerText = msg;
    banner.classList.remove('hidden');
    setTimeout(() => banner.classList.add('hidden'), 5000);
}

// ===========================
// NOTIFICATIONS
// ===========================

async function loadNotifications() {
    try {
        const res = await axios.get(`${API_URL}/notifications`, { 
            headers: { Authorization: `Bearer ${token}` } 
        });
        if (res.data.length > 0) {
            showNotification(res.data[0].message);
        }
    } catch (e) { 
        console.error('Notifications error:', e); 
    }
}

// ===========================
// MAP FUNCTIONS
// ===========================

function updateBusMarker(lat, lng) {
    if (busMarker) {
        busMarker.setLatLng([lat, lng]);
    } else {
        const busIcon = L.icon({
            iconUrl: 'data:image/svg+xml;base64,' + btoa('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="#ef4444"><path d="M17 20H7V21C7 21.5523 6.55228 22 6 22H5C4.44772 22 4 21.5523 4 21V20H3V12H2V8H3V5C3 3.89543 3.89543 3 5 3H19C20.1046 3 21 3.89543 21 5V8H22V12H21V20H20V21C20 21.5523 19.5523 22 19 22H18C17.4477 22 17 21.5523 17 21V20ZM5 5V14H19V5H5ZM5 16V18H9V16H5ZM15 16V18H19V16H15Z"/></svg>'),
            iconSize: [32, 32]
        });
        busMarker = L.marker([lat, lng], { icon: busIcon })
            .addTo(map)
            .bindPopup('🚌 Shuttle Bus');
    }
    map.panTo([lat, lng]);
}

function displayRouteStops(stops) {
    // Clear existing stop markers
    routeStopMarkers.forEach(marker => map.removeLayer(marker));
    routeStopMarkers = [];

    if (!stops || stops.length === 0) return;

    const stopIcon = L.icon({
        iconUrl: 'data:image/svg+xml;base64,' + btoa('<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#10b981"><circle cx="12" cy="12" r="10" stroke="white" stroke-width="2"/></svg>'),
        iconSize: [20, 20]
    });

    stops.forEach((stop, index) => {
        if (stop.lat && stop.lng) {
            const marker = L.marker([stop.lat, stop.lng], { icon: stopIcon })
                .addTo(map)
                .bindPopup(`🚏 ${stop.stop_name} (Stop ${index + 1})`);
            routeStopMarkers.push(marker);
        }
    });
}

// ===========================
// ROUTES
// ===========================

async function loadRoutes() {
    try {
        const response = await axios.get(`${API_URL}/routes`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        allRoutes = response.data;
        
        const routeSelect = document.getElementById('route-select');
        const driverRouteSelect = document.getElementById('driver-route-select');

        // Clear and populate
        if (routeSelect) {
            routeSelect.innerHTML = '<option value="">Choose a route...</option>';
            allRoutes.forEach(route => {
                routeSelect.innerHTML += `<option value="${route.id}">${route.name}</option>`;
            });
        }

        if (driverRouteSelect) {
            driverRouteSelect.innerHTML = '<option value="">Select route to start...</option>';
            allRoutes.forEach(route => {
                driverRouteSelect.innerHTML += `<option value="${route.id}">${route.name}</option>`;
            });
        }

        if (allRoutes.length > 0 && allRoutes[0].Stops) {
            displayStops(allRoutes[0].Stops);
            displayRouteStops(allRoutes[0].Stops);
            if (socket) socket.emit('join-route', allRoutes[0].id);
        }
    } catch (error) {
        console.error('Error loading routes', error);
        showToast('Failed to load routes', 'error');
    }
}

function displayStops(stops) {
    if (!stops) return;
    const tbody = document.getElementById('stops-table-body');
    tbody.innerHTML = stops.map((stop, index) => `
        <tr class="hover:bg-slate-50 transition-colors">
            <td class="p-3 border-b border-gray-100">
                <span class="font-medium text-slate-700">${stop.stop_name}</span>
            </td>
            <td class="p-3 border-b border-gray-100 text-center">
                <span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary-100 text-primary-700 font-bold text-xs">
                    ${index + 1}
                </span>
            </td>
        </tr>
    `).join('');
}

// Handle Route Selection (Student)
document.getElementById('route-select')?.addEventListener('change', async (e) => {
    const routeId = e.target.value;
    if (!routeId) return;

    const selectedRoute = allRoutes.find(r => r.id == routeId);

    // Populate Stops Dropdown
    const stopSelect = document.getElementById('stop-select');
    if (stopSelect && selectedRoute?.Stops) {
        stopSelect.innerHTML = '<option value="">Select Pick Up Point</option>';
        selectedRoute.Stops.forEach(stop => {
            stopSelect.innerHTML += `<option value="${stop.stop_name}">${stop.stop_name}</option>`;
        });
    }

    // Load Schedules
    try {
        const response = await axios.get(`${API_URL}/schedules/${routeId}`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        const schedules = response.data;
        const scheduleSelect = document.getElementById('schedule-select');
        scheduleSelect.innerHTML = '<option value="">Select Schedule</option>' +
            schedules.map(s => `<option value="${s.id}">${s.departure_time} (Bus: ${s.bus_number || 'N/A'})</option>`).join('');
    } catch (error) {
        console.error('Error loading schedules', error);
    }

    // Display stops
    if (selectedRoute) {
        displayStops(selectedRoute.Stops);
        displayRouteStops(selectedRoute.Stops);
    }

    if (socket) socket.emit('join-route', routeId);
});

// ===========================
// STUDENT: BOOKING
// ===========================

document.getElementById('book-btn')?.addEventListener('click', async () => {
    const scheduleSelect = document.getElementById('schedule-select');
    const stopSelect = document.getElementById('stop-select');
    const scheduleId = scheduleSelect?.value;
    const pickupStop = stopSelect?.value;

    if (!scheduleId) {
        return showToast('Please select a schedule', 'error');
    }
    if (stopSelect && !pickupStop) {
        return showToast('Please select a pick-up point', 'error');
    }

    try {
        await axios.post(`${API_URL}/bookings`, 
            { schedule_id: scheduleId, pickup_stop: pickupStop }, 
            { headers: { Authorization: `Bearer ${token}` } }
        );

        // Show Ticket Modal
        document.getElementById('ticket-name').innerText = currentUser.name;
        if (document.getElementById('ticket-pickup')) {
            document.getElementById('ticket-pickup').innerText = pickupStop || 'N/A';
        }

        try {
            const routeSelect = document.getElementById('route-select');
            const selectedRouteText = routeSelect.options[routeSelect.selectedIndex].text;
            const selectedTimeText = scheduleSelect.options[scheduleSelect.selectedIndex].text;
            
            document.getElementById('ticket-route').innerText = selectedRouteText;
            document.getElementById('ticket-time').innerText = selectedTimeText;
        } catch (e) {
            console.error('Error setting ticket details:', e);
        }

        document.getElementById('ticket-modal').classList.remove('hidden');
        showToast('Seat booked successfully! 🎉', 'success');
        
        if (currentUser.role === 'admin' || currentUser.role === 'coordinator') {
            loadAdminStats();
        }
    } catch (error) {
        showToast(error.response?.data?.error || 'Booking failed', 'error');
    }
});

// ===========================
// DRIVER: LOCATION SHARING
// ===========================

let tripActive = false;
let locationInterval = null;

document.getElementById('start-trip-btn')?.addEventListener('click', () => {
    const routeId = document.getElementById('driver-route-select')?.value;
    if (!routeId) {
        return showToast('Please select a route', 'error');
    }

    if (tripActive) {
        // Stop trip
        tripActive = false;
        clearInterval(locationInterval);
        document.getElementById('trip-status').innerText = '';
        document.getElementById('start-trip-btn').innerHTML = `
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
            </svg>
            Start Sharing Location
        `;
        showToast('Trip ended', 'success');
        return;
    }

    tripActive = true;
    document.getElementById('trip-status').innerText = '🟢 Sharing location...';
    document.getElementById('start-trip-btn').innerHTML = '⏹️ Stop Trip';
    document.getElementById('start-trip-btn').classList.remove('bg-gradient-to-r', 'from-primary-600', 'to-purple-600');
    document.getElementById('start-trip-btn').classList.add('bg-red-500', 'hover:bg-red-600');

    // Simulate movement (for demo)
    let lat = 2.9279 + (Math.random() - 0.5) * 0.01;
    let lng = 101.6413 + (Math.random() - 0.5) * 0.01;

    locationInterval = setInterval(() => {
        // Random movement simulation
        lat += (Math.random() - 0.5) * 0.001;
        lng += (Math.random() - 0.5) * 0.001;
        
        if (socket) {
            socket.emit('update-location', { routeId, lat, lng });
        }
        updateBusMarker(lat, lng);
    }, 3000);

    showToast('Trip started! Location is being shared.', 'success');
});

// ===========================
// DRIVER: INCIDENT REPORTING
// ===========================

document.getElementById('report-incident-btn')?.addEventListener('click', async () => {
    const type = document.getElementById('incident-type')?.value;
    const description = document.getElementById('incident-desc')?.value;

    if (!description || description.trim() === '') {
        return showToast('Please describe the incident', 'error');
    }

    try {
        await axios.post(`${API_URL}/incidents`, 
            { type, description }, 
            { headers: { Authorization: `Bearer ${token}` } }
        );
        
        showToast('Incident reported successfully', 'success');
        document.getElementById('incident-desc').value = '';
    } catch (e) {
        showToast('Failed to report incident', 'error');
    }
});

// ===========================
// ADMIN: SEND NOTIFICATION
// ===========================

document.getElementById('send-notify-btn')?.addEventListener('click', async () => {
    const message = document.getElementById('notify-msg')?.value;
    const target_role = document.getElementById('notify-target')?.value;

    if (!message || message.trim() === '') {
        return showToast('Please enter a message', 'error');
    }

    try {
        await axios.post(`${API_URL}/notifications`, 
            { message, type: 'alert', target_role }, 
            { headers: { Authorization: `Bearer ${token}` } }
        );
        
        showToast('Notification sent to ' + target_role, 'success');
        document.getElementById('notify-msg').value = '';
    } catch (e) {
        showToast('Failed to send notification', 'error');
    }
});

// ===========================
// ADMIN: STATISTICS
// ===========================

async function loadAdminStats() {
    try {
        const response = await axios.get(`${API_URL}/stats`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        const stats = response.data;
        const statsDiv = document.getElementById('admin-stats');

        statsDiv.innerHTML = `
            <div class="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border-2 border-blue-200">
                <p class="text-xs text-blue-600 uppercase font-bold mb-1">Total Users</p>
                <p class="text-3xl font-bold text-blue-900">${stats.totalUsers || 0}</p>
            </div>
            <div class="p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl border-2 border-green-200">
                <p class="text-xs text-green-600 uppercase font-bold mb-1">Bookings</p>
                <p class="text-3xl font-bold text-green-900">${stats.totalBookings || 0}</p>
            </div>
            <div class="p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl border-2 border-purple-200">
                <p class="text-xs text-purple-600 uppercase font-bold mb-1">Active Routes</p>
                <p class="text-3xl font-bold text-purple-900">${stats.activeRouteCount || 0}</p>
            </div>
            <div class="p-4 bg-gradient-to-br from-red-50 to-red-100 rounded-xl border-2 border-red-200">
                <p class="text-xs text-red-600 uppercase font-bold mb-1">Incidents</p>
                <p class="text-3xl font-bold text-red-900">${stats.recentIncidents || 0}</p>
            </div>
        `;
    } catch (e) { 
        console.error('Stats error:', e); 
    }
}

// ===========================
// UTILITIES
// ===========================

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast px-6 py-4 rounded-xl shadow-2xl text-white font-bold ${
        type === 'success' ? 'bg-gradient-to-r from-emerald-500 to-teal-500' : 'bg-gradient-to-r from-red-500 to-pink-500'
    }`;
    toast.innerHTML = `
        <div class="flex items-center gap-3">
            <span class="text-2xl">${type === 'success' ? '✓' : '✕'}</span>
            <span>${message}</span>
        </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.animation = 'slideInRight 0.3s ease-out reverse';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ===========================
// SESSION PERSISTENCE
// ===========================

window.onload = () => {
    const savedToken = localStorage.getItem('shuttle_token');
    const savedUser = localStorage.getItem('shuttle_user');
    
    if (savedToken && savedUser) {
        token = savedToken;
        currentUser = JSON.parse(savedUser);
        showDashboard();
    }
};

// Auto-refresh stats every 30 seconds for admins
setInterval(() => {
    if (currentUser && (currentUser.role === 'admin' || currentUser.role === 'coordinator')) {
        loadAdminStats();
    }
}, 30000);

console.log('🚀 Campus Shuttle System loaded successfully!');
