# 🚌 Campus Shuttle Scheduling and Tracking System

A comprehensive real-time web application for managing campus shuttle services. Built for T10L_Group09 - Software Engineering Final Project.

## 📋 Project Overview

This system provides a complete solution for campus transportation management with real-time GPS tracking, digital booking, and role-based access control for Students, Drivers, Coordinators, and Administrators.

### ✨ Key Features

#### For Students 👨‍🎓
- **Real-Time Bus Tracking** - See live shuttle locations on an interactive map
- **Digital Booking System** - Reserve seats and select pickup points
- **Instant Notifications** - Receive alerts for arrivals, delays, and route changes
- **Digital Boarding Pass** - Get a confirmation ticket after booking
- **View Booking History** - Track all your past and upcoming bookings

#### For Drivers 🚗
- **Live Location Sharing** - Automatically broadcast GPS location to students
- **Incident Reporting** - Report delays, breakdowns, or accidents instantly
- **Route Management** - View assigned routes and schedules
- **Easy Status Updates** - Simple interface for trip start/stop

#### For Coordinators 📊
- **Dashboard Analytics** - View real-time statistics and system health
- **Incident Management** - Review and resolve driver-reported issues
- **Broadcast Notifications** - Send alerts to specific user groups
- **Route Monitoring** - Oversee all active routes and shuttles

#### For Admins ⚙️
- **User Management** - Create, edit, and manage all user accounts
- **System Configuration** - Configure settings, security, and notifications
- **Audit Logs** - Track all system activities and changes
- **Complete System Control** - Full access to all features

## 🛠️ Technology Stack

### Frontend
- **HTML5** - Semantic markup
- **Tailwind CSS** - Modern utility-first styling
- **JavaScript (ES6+)** - Interactive features
- **Leaflet.js** - Interactive maps
- **Socket.IO Client** - Real-time updates
- **Axios** - HTTP requests

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **Socket.IO** - WebSocket real-time communication
- **Sequelize ORM** - Database management
- **SQLite** - Development database
- **JWT** - Secure authentication
- **Bcrypt** - Password hashing

## 🚀 Quick Start Guide

### Prerequisites
- Node.js (v14 or higher)
- npm (comes with Node.js)

### Installation

1. **Setup Backend**
   ```bash
   cd backend
   npm install
   node index.js
   ```
   Server starts on `http://localhost:3000`

2. **Setup Frontend** (new terminal)
   ```bash
   cd frontend
   npx -y serve -l 8080 .
   ```
   Frontend on `http://localhost:8080`

3. **Open Browser** → `http://localhost:8080`

## 👤 Demo Accounts

| Role | Email | Password |
|------|-------|----------|
| **Student** | `student@mmu.edu.my` | `student123` |
| **Driver** | `driver@mmu.edu.my` | `driver123` |
| **Coordinator** | `coord@mmu.edu.my` | `coord123` |
| **Admin** | `admin@mmu.edu.my` | `admin123` |

## 📊 Features Implemented

✅ User Authentication (JWT)  
✅ Real-time GPS Tracking (Socket.IO)  
✅ Digital Seat Booking  
✅ Incident Reporting  
✅ Push Notifications  
✅ Role-Based Access Control  
✅ Admin Dashboard  
✅ Responsive Design  
✅ Database Persistence  
✅ API Documentation  

## 👥 Team - T10L_Group09

- **Wadah Ali Mohammed Osman** - Transport Coordinator Module
- **Ahmad Akmal Asyraaf** - Driver Module  
- **Ardy Yamanni** - Student Module
- **Ali Badr Qaid** - Admin Module

## 📄 License

MIT License - Educational Use

---

**Built for MMU Software Engineering Course - January 2026**
